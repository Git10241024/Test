﻿using DataAccess.Models;
using DataAccess.Repositories;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ApplicationWeb.Pages
{
    public class IndexModel : PageModel
    {
        [BindProperty]
        public Personne nouvellePersonne { get; set; }

        private readonly ILogger<IndexModel> _logger;

        private readonly GenericRepository<Personne> personneRepository;
        private readonly RepositoryFactory repositoryFactory;

        public IndexModel(ILogger<IndexModel> logger, RepositoryFactory repositoryFactory)
        {
            _logger = logger;

            personneRepository = repositoryFactory.GetRepository<Personne>();
            this.repositoryFactory = repositoryFactory;
        }

        public void OnGet()
        {

        }


        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            personneRepository.Insert(nouvellePersonne);
            await repositoryFactory.SaveAsync();

            return RedirectToPage("./List");
        }
    }
}
