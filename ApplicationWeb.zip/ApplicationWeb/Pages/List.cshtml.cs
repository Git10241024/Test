using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DataAccess.Models;
using DataAccess.Repositories;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ApplicationWeb.Pages
{
    public class ListModel : PageModel
    {
        private readonly GenericRepository<Personne> personneRepository;
        private readonly RepositoryFactory repositoryFactory;
        public IEnumerable<Personne> Personnes { get; set; }

        public ListModel(RepositoryFactory repositoryFactory)
        {

            personneRepository = repositoryFactory.GetRepository<Personne>();
            this.repositoryFactory = repositoryFactory;
        }


        public void OnGet()
        {
            Personnes = this.personneRepository.Get(q => q.OrderBy(person => person.Nom));
        }
    }
}
