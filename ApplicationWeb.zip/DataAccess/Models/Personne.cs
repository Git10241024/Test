﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Models
{
    public class Personne
    {
        public int Id { get; set; }

        [Required]
        [MaxLength(255)]
        [RegularExpression(@"^[A-Z]+[a-zA-Z\s]*$")]
        [StringLength(255, MinimumLength = 3)]
        public string Nom { get; set; }

        [Required]
        [MaxLength(255)]
        [RegularExpression(@"^[A-Z]+[a-zA-Z\s]*$")]
        [StringLength(255, MinimumLength = 3)]
        public string Prenom { get; set; }


        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        [DataType(DataType.Date)]
        public DateTime DateDeNaissance { get; set; }

        [Range(0, 150)]
        public int Age
        {
            get
            {
                return DateTime.Now.Year - DateDeNaissance.Year;
            }
        }
    }
}
