﻿using DataAccess.Contexts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Repositories
{
    public class RepositoryFactory
    {

        private readonly MainContext mainContext;

        public RepositoryFactory(MainContext mainContext)
        {
            this.mainContext = mainContext;
        }
        public GenericRepository<T> GetRepository<T>() where T : class
        {
            return new GenericRepository<T>(mainContext);
        }

        public async Task SaveAsync()
        {
            await mainContext.SaveChangesAsync();
        }
    }
}
